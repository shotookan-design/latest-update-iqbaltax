import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, User, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const blogPosts = [
  {
    title: "GST/HST May Apply When Selling Short-Term Rentals",
    excerpt:
      "Recent CRA guidance clarifies when GST/HST obligations apply to short-term rental properties. Understanding these rules is crucial for property owners using platforms like Airbnb and VRBO.",
    author: "Nasar Iqbal",
    date: "March 15, 2024",
    category: "GST/HST",
    readTime: "5 min read",
    image: "/blog-gst-hst-rentals.png",
  },
  {
    title: "TFSA Overcontributions: Federal Court Critiques CRA",
    excerpt:
      "A recent Federal Court decision has criticized the CRA's approach to TFSA overcontribution penalties, providing important guidance for taxpayers facing similar assessments.",
    author: "Muhammad Hanif Shaikh",
    date: "March 8, 2024",
    category: "Tax Court",
    readTime: "7 min read",
    image: "/blog-tfsa-overcontributions.png",
  },
  {
    title: "Cryptocurrency Tax Reporting: 2024 Updates",
    excerpt:
      "New CRA guidance on cryptocurrency taxation brings clarity to digital asset reporting requirements. Learn what crypto investors and traders need to know for the 2024 tax year.",
    author: "Nasar Iqbal",
    date: "February 28, 2024",
    category: "Cryptocurrency",
    readTime: "6 min read",
    image: "/blog-crypto-tax-2024.png",
  },
  {
    title: "Voluntary Disclosures Program: Recent Changes and Opportunities",
    excerpt:
      "The CRA has updated its Voluntary Disclosures Program guidelines. Understanding these changes can help taxpayers resolve past compliance issues while minimizing penalties.",
    author: "Nasar Iqbal",
    date: "February 20, 2024",
    category: "VDP",
    readTime: "8 min read",
    image: "/blog-vdp-changes.png",
  },
  {
    title: "Director Liability for Corporate Tax Debts: Key Defenses",
    excerpt:
      "Corporate directors can face personal liability for unpaid corporate taxes. Learn about the key defenses available and how to protect yourself from CRA collection actions.",
    author: "Muhammad Hanif Shaikh",
    date: "February 12, 2024",
    category: "Corporate Tax",
    readTime: "6 min read",
    image: "/blog-director-liability.png",
  },
  {
    title: "Tax Residency Determination: Recent Court Decisions",
    excerpt:
      "Recent court cases have clarified factors the CRA considers when determining tax residency. These decisions have important implications for individuals with ties to multiple countries.",
    author: "Nasar Iqbal",
    date: "January 30, 2024",
    category: "Tax Residency",
    readTime: "9 min read",
    image: "/blog-tax-residency.png",
  },
]

export function BlogPosts() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-serif font-bold text-primary">Latest Articles</h2>
        <p className="text-gray-700">{blogPosts.length} articles</p>
      </div>

      <div className="space-y-8">
        {blogPosts.map((post, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
            <CardContent className="p-0">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
                <div className="md:col-span-1">
                  <img
                    src={post.image || "/placeholder.svg?height=200&width=300"}
                    alt={post.title}
                    className="w-full h-48 md:h-full object-cover"
                  />
                </div>
                <div className="md:col-span-2 p-6">
                  <div className="flex items-center space-x-4 mb-3">
                    <Badge className="bg-accent/10 text-accent hover:bg-accent/20">{post.category}</Badge>
                    <span className="text-sm text-gray-600">{post.readTime}</span>
                  </div>

                  <h3 className="text-xl font-serif font-bold text-gray-900 mb-3 hover:text-primary transition-colors cursor-pointer">
                    {post.title}
                  </h3>

                  <p className="text-gray-700 leading-relaxed mb-4">{post.excerpt}</p>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center">
                        <User className="h-4 w-4 mr-1" />
                        {post.author}
                      </div>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {post.date}
                      </div>
                    </div>
                    <Button variant="ghost" className="text-primary hover:text-primary/80">
                      Read More
                      <ArrowRight className="h-4 w-4 ml-1" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="text-center pt-8">
        <Button
          size="lg"
          variant="outline"
          className="border-primary text-primary hover:bg-primary hover:text-white bg-transparent"
        >
          Load More Articles
        </Button>
      </div>
    </div>
  )
}
