import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Sarah Mitchell",
    role: "Small Business Owner",
    content:
      "Nasar and his team saved my business during a complex CRA audit. Their expertise and strategic approach resulted in a favorable resolution that I never thought possible. Highly recommended!",
    rating: 5,
  },
  {
    name: "David Chen",
    role: "Real Estate Investor",
    content:
      "The voluntary disclosure process seemed overwhelming until I found Iqbal Law. They guided me through every step and minimized the penalties significantly. Professional and trustworthy service.",
    rating: 5,
  },
  {
    name: "Maria Rodriguez",
    role: "Corporate Executive",
    content:
      "Exceptional tax planning services that saved our company substantial amounts. The team's deep knowledge of Canadian tax law and attention to detail is impressive.",
    rating: 5,
  },
]

export function TestimonialSection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-serif font-bold text-primary mb-4">What Our Clients Say</h2>
          <p className="text-xl text-gray-600">Trusted by hundreds of satisfied clients across Ontario</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-accent fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 leading-relaxed italic">"{testimonial.content}"</p>
                <div>
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-gray-600">{testimonial.role}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
